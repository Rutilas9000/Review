/**
 * @Class: MethodPractice
 * @Author: Savion Plater
 * @Course: ITEC 2150 - 05, Fall 2023
 * @Written: August 19, 2023
 * Description:  Write an instance method called `calculateSquare`
 * that takes an integer parameter and returns its square.
 * Create an instance method named `printName` that
 * accepts a string parameter `name` and prints "Hello, [name]!".
 */
public class MethodPractice {
    public static int calculateSquare(int num){
        return num * num;
    }

    public static String printName(String name){
       System.out.println("Hello, " + name + "!");
    return "";
    }
    public static void main(String[] args){
        System.out.println(calculateSquare(99));
        System.out.println(printName("Savion"));
    }
}

