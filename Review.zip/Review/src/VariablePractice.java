/**
 * @Class: VariablePractice
 * @Author: Savion Plater
 * @Course: ITEC 2150 - 05, Fall 2023
 * @Written: August 19, 2023
 * Description: Declares and prints a variable named temperature.
 * Creates two variables called firstName and lastName and combine them.
 */
public class VariablePractice {
    public static void main(String[] args) {
        int temperature = 25;
        System.out.println(temperature);
        String firstName = "Savion";
        String lastName = "Plater";
        System.out.println(firstName + " " + lastName);
    }
}
