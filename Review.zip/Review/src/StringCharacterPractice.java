/**
 * @Class: StringCharacterPractice
 * @Author: Savion Plater
 * @Course: ITEC 2150 - 05, Fall 2023
 * @Written: August 19, 2023
 * Description: Creates and print a string message along with its length.
 * Creates a string variable containing a quote and prints it alongside
 * the character in its tenth position.
 */
public class StringCharacterPractice {
    public static void main(String[] args){
        String message = "Hello, World!";
        System.out.println(message.length());
        String quote = "More than meets the eye";
        System.out.println(quote + ", " + quote.charAt(10));
    }
}
