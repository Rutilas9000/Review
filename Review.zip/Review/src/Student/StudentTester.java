package Student;

public class StudentTester {
    public static void main(String[] args){
        Student[] students = {
                new Student("Savion", 23),
                new Student("Sasha", 22),
                new Student("Richard", 19),
                new Student("Jose", 18),
                new Student("Cade", 21),
        };

        System.out.println("Students older than 20 years old: ");
        for(Student student : students){
            if (student.getAge() > 20){
                System.out.println(student.getName());
            }
        }
    }
}
