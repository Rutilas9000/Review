package Student;
public class Student {
    private String name;
    private int age;


    public Student(String studentName, int studentAge) {
        this.name = studentName;
        this.age = studentAge;
    }

    public String toString() {
        return String.format("Student(name: %s, age: %d)", name, age);
    }

    public int getAge() {
        return age;
    }

    public String getName() {
        return name;
    }
}
