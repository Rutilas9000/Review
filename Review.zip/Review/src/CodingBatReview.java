public class CodingBatReview {
    public int sumDigits(int n) {
        if (n == 0) {
            return 0;
        } else {
            int sum = 0;
            while (n > 0) {
                sum += n % 10;
                n /= 10;
            }
            return sum;
        }
    }

    public long factorial(int number){
        if(number<1 || number>20){
            return 1;
        }
        return number*factorial(number-1);
    }

    public boolean isLeapYear(int year){
        if ((year & 3) != 0) {
            return false;
        }

        if ((year % 100) != 0) {
            return true;
        }

        return (year % 400) == 0;
    }

    public int countOccurrences(String text, char target) {
        int count = 0;
        for (int i = 0; i < text.length(); i++) {
            if (text.charAt(i) == target) {
                count++;
            }
        }
        return count;
    }

    public int countVowels(String s) {
        int count = 0;
        for(int i = 0; i < s.length(); i++) {
            if(s.charAt(i) == 'a' || s.charAt(i) == 'e' || s.charAt(i) == 'i' || s.charAt(i) == 'o' || s.charAt(i) == 'u') {
                count++;
            }
        }
        return count;
    }

    public int[] reverseArray(int[] nums) {
        int[] newA = new int[nums.length];

        for (int i = 0; i < nums.length; i++) {
            newA[nums.length - 1 - i] = nums[i];
        }

        return newA;
    }

}
