import java.util.Scanner;

/**
 * @Class: LoopPractice2
 * @Author: Savion Plater
 * @Course: ITEC 2150 - 05, Fall 2023
 * @Written: August 19, 2023
 * Description: Implement a program that repeatedly asks
 * the user for a number until they enter a negative
 * number. Print the sum of all the positive numbers entered.
 */
public class LoopPractice2 {
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Input a positive number");
            int number = Integer.valueOf(scanner.nextLine());

            if (number == 0) {
                break;
            }

            if (number < 0) {
                System.out.println("Negative number. Enter a positive number.");
                continue;
            }

            System.out.println(number * number);
        }
    }
}
