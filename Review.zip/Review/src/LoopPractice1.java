/**
 * @Class: LoopPractice1
 * @Author: Savion Plater
 * @Course: ITEC 2150 - 05, Fall 2023
 * @Written: August 19, 2023
 * Description: Uses a for loop to print even numbers from 2 to 10.
 */
public class LoopPractice1 {
    public static void main(String[] args) {
        int number = 10;
        for (int i = 2; i <= number; i++) {
            //check if the number is even or not
            //if i%2 is equal to zero, the number is even
            if (i % 2 == 0) {
                System.out.print(i + " ");
            }
        }
    }
}
