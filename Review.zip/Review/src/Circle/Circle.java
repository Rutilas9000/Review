/**
 * @Class: Circle
 * @Author: Savion Plater
 * @Course: ITEC 2150 - 05, Fall 2023
 * @Written: August 19, 2023
 * Description: Create a class `Circle` with a field
 * `radius` and a method `calculateArea()` that returns the area of the circle.
 */
package Circle;
public class Circle {
    private double radius;

    public Circle(){
        this.radius = 0;
    }

    //Constructor with one parameter
    public Circle(double newRadius){
        this.radius = newRadius;
    }

    //getter - accessor
    public double getRadius(){
        return radius; //this.radius
    }

    //mutator or setter
    //this method is not returning value but changing the value.

    public void setRadius(double newRadius){
        this.radius = newRadius;}

        public double calculateArea(){
            double area = Math.PI * this.radius * this.radius;
            return area;
        }

    }
