package Circle;

public class CircleTester {
    public static void main(String[] args){
       Circle circle = new Circle();
        System.out.println("First Default Value: " + circle.getRadius());
        System.out.println("Area with the first default value: " + circle.calculateArea());
        circle.setRadius(5);

        System.out.println("After change radius value to 5: " +
                circle.getRadius());
        System.out.println("After change radius value to 5. Area is : " + circle.calculateArea());


    }
}
