/**
 * @Class: ArrayPractice1
 * @Author: Savion Plater
 * @Course: ITEC 2150 - 05, Fall 2023
 * @Written: August 19, 2023
 * Description:  Declare an array of integers with values 5, 10, 15, 20, and 25.
 * Calculate and print the sum of all the elements.
 */
public class ArrayPractice1 {
    static int array[] = {5, 10, 15, 20, 25};

    static int sum(){
        int sum = 0;
        int i;

        for(i = 0; i < array.length; i++){
            sum += array[i];
        }
        return sum;
    }

    public static void main(String[] args){
        System.out.println(" the sum of all elements is " + sum());
    }
}
