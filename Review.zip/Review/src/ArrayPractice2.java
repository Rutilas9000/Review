/**
 * @Class: ArrayPractice2
 * @Author: Savion Plater
 * @Course: ITEC 2150 - 05, Fall 2023
 * @Written: August 19, 2023
 * Description: Write a program that finds the maximum
 * value in an array of integers.
 */
public class ArrayPractice2 {
    static int array[] = {5, 15, 62, 34, 77, 28, 93, 41};

    static int maximum(){
        int i;
        int max = array[0];

        for(i = 1; i < array.length; i++){
            if(array[i] > max){
                max = array[i];
            }
        }
        return max;
    }

    public static void main(String[] args){
        System.out.println("The maximum value in the array is " + maximum());
    }
}
